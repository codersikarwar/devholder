<?php

define('SITE_TITLE','DevHolder');
define('SITE_URL','https://devholder.000webhostapp.com');
define('SITE_LOGO','Dev<span class="logo__thin">Holder</span>');
define('SITE_DESCRIPTION','Empower Your Design Journey with Dynamic image placeholders. '.SITE_TITLE.' Provides free Image Placeholders in svg, png and jpg Format');
define('SITE_TAGLINE','Free Placeholders Image Api for Designers');
define('AUTHOR_NAME','Bhoopendra Singh Sikarwar');
define('AUTHOR_URL','https://instagram.com/bhoopendra.here');

?>